## 1 [[http коды ошибок, методы]]

## 2 [[http1 vs http 2]]

## 3 [[https vs http]]

## 4 [[Идемпотентность в http]]